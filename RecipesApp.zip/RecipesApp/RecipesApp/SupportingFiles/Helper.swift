//
//  Helper.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 26/02/22.
//

import SwiftUI

class Helper {
    
    static let shared = Helper()
    
    private init() {}
    
    func getUsers() -> [User] {
        @AppStorage("users") var users: Data = Data()
        guard let users = try? JSONDecoder().decode([User].self, from: users) else { return [] }
        return users
    }
    
    func getLayout(with coloums: Int) -> [GridItem] {
        var layout: [GridItem] = []
        for _ in 0..<coloums {
            layout.append(GridItem(.flexible()))
        }
        return layout
    }
    
    func deviceIsOnPortraitMode() -> Bool {
        guard let scene = UIApplication.shared.keyWindow?.windowScene else {
            return true
        }
        return scene.interfaceOrientation.isPortrait
    }
        
}
