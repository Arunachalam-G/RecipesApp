//
//  Constants.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 20/02/22.
//

import Foundation

// Fonts
let kPoppinsRegular = "Poppins-Regular.ttf"
let kPoppinsLight = "Poppins-Light"
let kPoppinsMedium = "Poppins-Medium"
let kPoppinsSemiBold = "Poppins-SemiBold"
let kPoppinsBold = "Poppins-Bold"

// Images
let kImageLogin = "FoodLogin"
let kSoupTopped = "SoupTopped"
let kHoneyPie = "HoneyPie"
let kHoneyPie2 = "HoneyPie2"
let kUser = "UserH"

// Hex color
let kBlack = "010101"
let kGray = "AAADAE"
let KTextFieldTextColor = "404245"
let kYellow = "E7CF8C"
let kYellowButtonBackground = "F5C960"
let kCreateAccountTextColor = "a4a5a5"

// Alert texts
let kSingedIn = "Successfully logged in..."
let kSignedUp = "Successfully signed up..."
let kEmailExists = "Email alreay registered. Try login."
let kPasswordMisMatch = "Password is not matching with confirmed password."
let kFieldEmpty = "Please fill all fields."
let kInvalidEmail = "Invalid mail id. Please enter valid one."
let kWeakPassword = "Password should have atleast 6 characters.";
let kInvalidCredentials = "Invalid login credentials."
