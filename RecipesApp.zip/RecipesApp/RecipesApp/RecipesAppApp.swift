//
//  RecipesAppApp.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 20/02/22.
//

import SwiftUI
import IQKeyboardManagerSwift

@main
struct RecipesAppApp: App {
    
    init() {
        IQKeyboardManager.shared.enable = true
        IQKeyboardManager.shared.enableAutoToolbar = false
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
