//
//  SignupView.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 23/02/22.
//

import SwiftUI

enum SignupFields {
    case name, email, password, confirmPassword
}

struct SignupView: View {
    
    @Environment(\.presentationMode) var presentationMode
    @AppStorage("users") private var users: Data = Data()
    @State var name: String = ""
    @State var email: String = ""
    @State var password: String = ""
    @State var confirmPassword: String = ""
    @FocusState var focusedField: SignupFields?
    @State var alertMessage: String = ""
    @State var showAlert = false
    @Binding var isLoggedIn: Bool
    
    var signinText: AttributedString {
        var text = AttributedString("Already have a account? Sign in.")
        text.font = .custom(kPoppinsBold, size: 15)
        text.foregroundColor = Color(hex: kCreateAccountTextColor)
        if let range = text.range(of: "Sign in.") {
            text[range].foregroundColor = Color(hex: kYellowButtonBackground)
        }
        return text
    }
    
    init(isLoggedIn: Binding<Bool>) {
        if let font = UIFont(name: kPoppinsBold, size: 25) {
            UINavigationBar.appearance().largeTitleTextAttributes = [.font : font]
        }
        _isLoggedIn = isLoggedIn
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 30) {
                SignupField(text: $name, placeholder: "Full name", fieldIcon: "person", focusedField: $focusedField, field: .name, submitLabel: .next) {
                    focusedField = .email
                }
                
                SignupField(text: $email, placeholder: "Email", fieldIcon: "envelope", focusedField: $focusedField, field: .email, submitLabel: .next) {
                    focusedField = .password
                }
                
                SignupField(text: $password, placeholder: "Password", fieldIcon: "lock", isPassword: true, focusedField: $focusedField, field: .password, submitLabel: .next) {
                    focusedField = .confirmPassword
                }
                
                SignupField(text: $confirmPassword, placeholder: "Confirm Password", fieldIcon: "lock", isPassword: true, focusedField: $focusedField, field: .confirmPassword, submitLabel: .done) {
                    focusedField = nil
                }
                
                SignupButton(onTap: signup)
                    .alert(alertMessage, isPresented: $showAlert) {
                        Button("Ok", role: .cancel) {
                            if alertMessage == kSignedUp {
                                isLoggedIn = true
                            }
                        }
                    }
                
                Spacer()
                
                Text(signinText)
                    .padding(.bottom)
                    .onTapGesture {
                        goBack()
                    }
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 50)
        .navigationBarTitle("Create New Account")
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading: CustomBackButton(onTap: goBack))
    }
    
    func goBack() {
        presentationMode.wrappedValue.dismiss()
    }
    
    func signup() {
        if name.empty() || email.empty() || password.empty() || confirmPassword.empty() {
            showAlert(message: kFieldEmpty)
            return
        }
        
        if !isValid(email: email) {
            showAlert(message: kInvalidEmail)
            return
        }
        
        var existingUsers = Helper.shared.getUsers()
        
        if existingUsers.contains(where: { user in
            user.email == email
        }) {
            showAlert(message: kEmailExists)
            return
        }
        
        if !isValid(password: password) {
            showAlert(message: kWeakPassword)
            return
        }
        
        if password != confirmPassword {
            showAlert(message: kPasswordMisMatch)
            return
        }
        
        let newUser = User(name: name, email: email, password: password)
        existingUsers.append(newUser)
        guard let data = try? JSONEncoder().encode(existingUsers) else { return }
        users = data
        showAlert(message: kSignedUp)
    }
    
    func showAlert(message: String) {
        alertMessage = message
        showAlert = true
    }
    
    func isValid(email: String) -> Bool {
        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        return emailPredicate.evaluate(with: email)
    }
    
    func isValid(password: String) -> Bool {
        password.count >= 6
    }
}

struct SignupButton: View {
    var onTap: () -> () = {}
    
    var body: some View {
        HStack {
            Spacer()
            Button(action: onTap) {
                HStack {
                    Text("SIGN UP")
                    Image(systemName: "arrow.right")
                }
                .font(.custom(kPoppinsBold, size: 20))
                .foregroundColor(.white)
                .padding(.horizontal)
                .frame(height: 50)
                .background(Color.yellow)
                .cornerRadius(25)
            }
        }
    }
    
}

struct SignupField: View {
    
    @Binding var text: String
    var placeholder: String
    var fieldIcon: String
    var isPassword = false
    var focusedField: FocusState<SignupFields?>.Binding
    var field: SignupFields
    var submitLabel: SubmitLabel
    var onSubmit: () -> () = { }
    
    var body: some View {
        VStack {
            HStack {
                Image(systemName: fieldIcon)
                    .resizable()
                    .frame(width: 30, height: 30)
                    .symbolVariant(.circle)
                    .foregroundColor(.yellow)
                if isPassword {
                    SecureField("", text: $text)
                        .placeholder(when: text.isEmpty) {
                            Text(placeholder.uppercased())
                                .font(.custom(kPoppinsMedium, size: 18))
                                .foregroundColor(.black)
                        }
                        .font(.custom(kPoppinsMedium, size: 18))
                        .submitLabel(submitLabel)
                        .onSubmit {
                            onSubmit()
                        }
                } else {
                    TextField("", text: $text)
                        .placeholder(when: text.isEmpty) {
                            Text(placeholder.uppercased())
                                .font(.custom(kPoppinsMedium, size: 18))
                                .foregroundColor(.black)
                        }
                        .font(.custom(kPoppinsMedium, size: 18))
                        .focused(focusedField, equals: field)
                        .submitLabel(submitLabel)
                        .keyboardType(field == .email ? .emailAddress : .default)
                        .textInputAutocapitalization(field == .email ? .never : .sentences)
                        .onSubmit {
                            onSubmit()
                        }
                }
            }
            .foregroundColor(.black)
            Divider()
        }
        
    }
}

struct CustomBackButton: View {
    
    var onTap: () -> () = {}
    
    var body: some View {
        Image(systemName: "arrow.left")
            .resizable()
            .frame(width: 40, height: 40)
            .symbolVariant(.circle.fill)
            .foregroundStyle(.black, .yellow)
            .onTapGesture {
                onTap()
            }
    }
}

struct SignupView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            SignupView(isLoggedIn: .constant(false))
        }
    }
}
