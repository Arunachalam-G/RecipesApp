//
//  ReusableViews.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 23/02/22.
//

import SwiftUI

struct RecipesTitleView: View {
    
    @Binding var isLoggedIn: Bool
    var forExplore: Bool = false
    var onMenuTap: () -> () = {}
    
    var body: some View {
        HStack {
            Image("Menu")
                .font(.custom(kPoppinsBold, size: 30))
                .padding(.horizontal)
                .onTapGesture {
                    onMenuTap()
                }
            
            Spacer()
            
            Text(forExplore ? "Explore" : "Recipes")
                .font(.title)
                .bold()
            
            Spacer()
            
            Image(kUser)
                .resizable()
                .frame(width: 40, height: 40)
                .clipShape(Circle())
                .padding(.horizontal)
                .onTapGesture {
                    isLoggedIn = false
                }
        }
    }
}
