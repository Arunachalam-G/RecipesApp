//
//  IngredientCell.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 23/02/22.
//

import SwiftUI

struct IngredientCell: View {
    var ingredient: Ingredient
    
    var body: some View {
        VStack {
            HStack(spacing: 25) {
                Image(ingredient.image)
                    .resizable()
                    .frame(width: 50, height: 50)
                
                Text(ingredient.name)
                    .font(.custom(kPoppinsBold, size: 16))
                    .foregroundColor(.black)
                    .lineLimit(2)
                
                Spacer()
                
                Text(ingredient.quantity)
                    .font(.custom(kPoppinsSemiBold, size: 14))
                    .foregroundColor(Color(hex: kGray))
            }
            
            Divider()
        }
    }
}

struct IngredientCell_Previews: PreviewProvider {
    static var previews: some View {
        IngredientCell(ingredient: raspberry)
    }
}
