//
//  RecipeDetailView.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 23/02/22.
//

import SwiftUI

struct RecipeDetailView: View {
    @Environment(\.presentationMode) var presentationMode
    var recipe: Recipe
    
    init(recipe: Recipe) {
        self.recipe = recipe
        UIScrollView.appearance().bounces = false
    }
    
    var body: some View {
        ScrollView {
            ZStack {
                VStack {
                    RecipeImage(image: recipe.image, onTap: goBack)
                    Spacer()
                }
                
                Rectangle()
                    .foregroundColor(.clear)
                    .frame(height: 200)
                    .offset(y: 650)
                    .padding(.bottom, 650)
                    .overlay(alignment: .topTrailing) {
                        HStack {
                            Spacer()
                            VStack(spacing: 20) {
                                RecipeActionOverlay(image: "square.and.arrow.up", height: 40)
                                RecipeActionOverlay(image: "play", height: 30, forPlay: true)
                            }
                        }
                        .padding(.bottom, 50)
                    }
                
                
                RecipeNutiritionAndIngredientsView(recipe: recipe)
                    .background(.white)
                    .cornerRadius(50)
                    .offset(y: 400)
                    .padding(.bottom, 400)
            }
        }
        .ignoresSafeArea()
        .navigationBarHidden(true)
        .statusBar(hidden: true)
    }
    
    func goBack() {
        presentationMode.wrappedValue.dismiss()
    }
}

struct RecipeActionOverlay: View {
    var image: String
    var height: CGFloat
    var forPlay: Bool = false
    
    var body: some View {
        ZStack {
            Circle()
                .fill(.black.opacity(0.4))
                .frame(width: 70, height: 70)
            Image(systemName: image)
                .resizable()
                .symbolVariant(forPlay ? .rectangle : .none)
                .frame(width: 30, height: height)
                .foregroundColor(.white)
        }
        .padding(.trailing, 50)
    }
}

struct RecipeNutiritionAndIngredientsView: View {
    
    var recipe: Recipe
    
    var body: some View {
        VStack(alignment: .leading, spacing: 25) {
            SwiperView()
            
            RecipeInfoView(recipe: recipe)
            
            NutritionFactsView(recipe: recipe)
            
            IngredientsView(ingredients: recipe.ingredients)
                .padding(.top, 10)
        }
        .padding(.all, 50)
    }
}

struct RecipeInfoView: View {
    var recipe: Recipe
    
    var body: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 10) {
                Text(recipe.name)
                    .font(.custom(kPoppinsBold, size: 22))
                    .foregroundColor(.black)
                Text(recipe.type)
                    .font(.custom(kPoppinsRegular, size: 20))
                    .foregroundColor(Color(hex: kGray))
            }
            
            Spacer()
            
            RatingOverlay(rating: recipe.rating)
        }
    }
}

struct SwiperView: View {
    var body: some View {
        HStack {
            Spacer()
            Capsule()
                .fill(Color(hex: kGray))
                .frame(width: 60, height: 5)
            Spacer()
        }
    }
}

struct NutritionFactsView: View {
    
    var recipe: Recipe
    
    var body: some View {
        Section {
            HStack {
                NutritionView(name: "Calories", quantity: "\(recipe.calories)", unit: "kcal")
                Spacer()
                NutritionView(name: "Carbs", quantity: "\(recipe.carbohydrates)", unit: "g")
                Spacer()
                NutritionView(name: "Protein", quantity: "\(recipe.protein)", unit: "g")
                Spacer()
                NutritionView(name: "Fat", quantity: "\(recipe.fat)", unit: "g")
            }
        } header: {
            Text("Nutirition Facts".uppercased())
                .font(.custom(kPoppinsBold, size: 15))
                .foregroundColor(Color(hex: kGray))
        }
    }
}

struct NutritionView: View {
    var name: String
    var quantity: String
    var unit: String
    
    var body: some View {
        VStack {
            ZStack {
                Circle()
                    .fill(.white)
                    .frame(width: 50,height: 60)
                Text(quantity)
                    .font(.custom(kPoppinsSemiBold, size: 20))
            }
            .offset(y: 6)
            .padding(.bottom, 6)
            
            Spacer()
            
            Text(name)
                .font(.custom(kPoppinsBold, size: 11))
            
            Text(unit)
                .font(.custom(kPoppinsRegular, size: 11))
            
            Spacer()
        }
        .padding(.horizontal, 5)
        .padding(.bottom, 15)
        .frame(height: 150)
        .background(Color(hex: kYellowButtonBackground))
        .clipShape(Capsule())
    }
}

struct IngredientsView: View {
    
    var ingredients: [Ingredient]
    
    var body: some View {
        Section {
            ForEach(ingredients, id: \.self) { ingredient in
                IngredientCell(ingredient: ingredient)
            }
        } header: {
            Text("Ingredients".uppercased())
                .font(.custom(kPoppinsBold, size: 15))
                .foregroundColor(Color(hex: kGray))
            
        }
    }
}

struct RecipeImage: View {
    
    var image: String
    var onTap: () -> () = {}
    
    var body: some View {
        Image(image)
            .resizable()
            .aspectRatio(contentMode: .fit)
            .overlay(alignment: .topLeading) {
                CustomBackButton(onTap: onTap)
                    .padding(.all, 30)
            }
    }
}

struct RecipeDetailView_Previews: PreviewProvider {
    static var previews: some View {
        RecipeDetailView(recipe: kTestRecipes[4])
    }
}
