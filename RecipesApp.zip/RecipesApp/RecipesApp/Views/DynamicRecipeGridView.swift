//
//  DynamicRecipeGridView.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 27/02/22.
//

import SwiftUI

struct DynamicRecipeGridView<Content: View, T: Identifiable>: View where T: Hashable {
    var content: (T) -> Content
    var list: [T]
    
    var showIndicators: Bool
    var spacing: CGFloat
    
    var columns: Int
    
    var align: Bool = false
    
    init(columns: Int, showIndicators: Bool = false, spacing: CGFloat = 10, list: [T], @ViewBuilder content: @escaping (T) -> Content) {
        self.content = content
        self.list = list
        self.showIndicators = showIndicators
        self.spacing = spacing
        self.columns = columns
    }
    
    func setUpList() -> [[T]] {
        var gridArray: [[T]] = Array(repeating: [], count: columns)
        
        var currentIndex = 0
        
        for object in list {
            gridArray[currentIndex].append(object)
            currentIndex = currentIndex == (columns - 1) ? 0 : (currentIndex + 1)
        }
        
        return gridArray
    }
    
    var body: some View {
        ScrollView(.vertical, showsIndicators: showIndicators) {
            HStack(alignment: .top) {
                ForEach(setUpList(), id: \.self) { columnDatas in
                    LazyVStack(spacing: spacing) {
                        ForEach(columnDatas) { object in
                            content(object)
                        }
                    }
                }
            }
            .padding(.all)
        }
    }
}
