//
//  RecipeCell.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 22/02/22.
//

import SwiftUI

struct RecipeGridCell: View {
    
    var recipe: Recipe
    
    var body: some View {
        VStack(alignment: .leading) {
            Image(recipe.image)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .cornerRadius(24)
                .overlay(alignment: .bottomTrailing) {
                    RatingOverlay(rating: recipe.rating)
                        .padding()
                }
                .overlay(alignment: .topLeading) {
                    DurationOverlay(duration: recipe.duration)
                }
            Text(recipe.name)
                .font(.custom(kPoppinsBold, size: 20))
                .foregroundColor(.black)
                .lineLimit(1)
            Text(recipe.type)
                .font(.custom(kPoppinsMedium, size: 18))
                .foregroundColor(Color(hex: kGray))
        }
    }
}

struct RecipeExploreCell: View {
    
    var recipe: Recipe
    
    var body: some View {
        VStack(alignment: .leading) {
            Image(recipe.image)
                .resizable()
                .cornerRadius(24)
                .aspectRatio(2/2.5, contentMode: .fit)
            
            HStack {
                RatingOverlay(rating: recipe.rating)
                Text(recipe.duration)
                    .font(.custom(kPoppinsSemiBold, size: 14))
                    .foregroundColor(.black)
            }
        }
    }
}

struct DurationOverlay: View {
    
    var duration: String
    
    var body: some View {
        Label(" \(duration) ", systemImage: "clock.fill")
            .foregroundColor(.white.opacity(1))
            .frame(height: 30)
            .padding(.horizontal, 5)
            .background(Color.black.opacity(0.4))
            .cornerRadius(15)
            .font(.custom(kPoppinsBold, size: 12))
            .padding()
    }
}

struct RatingOverlay: View {
    
    var rating: Double
    
    var body: some View {
        ZStack {
            Capsule()
                .fill(Color(hex: kYellowButtonBackground))
                .frame(width: 70, height: 30)
            HStack(spacing: 5) {
                Image(systemName: "star.fill")
                    .font(.caption)
                Text("\(rating.formatted(.number.precision(.fractionLength(1))))")
                    .font(.custom(kPoppinsSemiBold, size: 14))
            }
            .foregroundColor(.black)
            .frame(width: 70, height: 30)
        }
    }
}


struct RecipeCell_Previews: PreviewProvider {
    static var previews: some View {
        RecipeGridCell(recipe: kTestRecipes[1])
    }
}
