//
//  RecipesView.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 22/02/22.
//

import SwiftUI

enum FoodTypes: CaseIterable {
    case all, italian, asian, veg, nonVeg, chinese
    
    func type() -> String {
        switch self {
        case .all:
            return "All"
        case .italian:
            return "Italian"
        case .asian:
            return "Asian"
        case .veg:
            return "Vegetarian"
        case .nonVeg:
            return "Non-Vegetarian"
        case .chinese:
            return "Chinese"
        }
    }
}

struct RecipesView: View {
    
    @Binding var isLoggedIn: Bool
    @State var searchText: String = ""
    @State var foodType: FoodTypes = .all
    
    var body: some View {
        NavigationView {
            VStack(spacing: 24) {
                RecipesTitleView(isLoggedIn: $isLoggedIn)
                
                SearchBar(searchText: $searchText)
                
                FoodTypeSelectionView(foodType: $foodType)
                
                RecipeCollection()
            }
            .navigationBarHidden(true)
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct RecipeCollection: View {
    @State var coloumns = UIDevice.current.userInterfaceIdiom == .phone ? 2 : 3
    @State var disappeard = false
    
    var body: some View {
        DynamicRecipeGridView(columns: coloumns, list: kTestRecipes) { recipe in
            NavigationLink {
                RecipeExploreView(isLoggedIn: .constant(true), foodType: recipe.type)
            } label: {
                RecipeGridCell(recipe: recipe)
            }
        }.onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in
            if !disappeard {
                coloumns = Helper.shared.deviceIsOnPortraitMode() ? 2 : 3
            }
        }
        .onAppear {
            disappeard = false
        }
        .onDisappear {
            disappeard = true
        }
    }
    
}

struct FoodTypeSelectionView: View {
    @Binding var foodType: FoodTypes
    
    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 16) {
                ForEach(FoodTypes.allCases, id: \.self) { food in
                    let isSelectedType = food == foodType
                    VStack(spacing: 7) {
                        Text("  \(food.type())  ")
                            .font(.custom(isSelectedType ? kPoppinsBold : kPoppinsRegular, size: 20))
                            .foregroundColor(Color(hex: isSelectedType ? kBlack : kGray))
                        Capsule()
                            .fill(Color(hex: kYellowButtonBackground).opacity(isSelectedType ? 1 : 0))
                            .frame(height: 5)
                    }
                    .onTapGesture {
                        didSelect(type: food)
                    }
                    Spacer()
                }
            }
            .padding(.leading)
        }
        .padding(.leading)
        .padding(.trailing, -10)
    }
    
    func didSelect(type: FoodTypes) {
        foodType = type
    }
}

struct SearchBar: View {
    
    @Binding var searchText: String
    
    var body: some View {
        TextField("", text: $searchText)
            .placeholder(when: searchText.isEmpty, placeholder: {
                Text("Search Recipes")
                    .foregroundColor(.black)
                    .font(.custom(kPoppinsMedium, size: 20))
            })
            .foregroundColor(.black)
            .font(.custom(kPoppinsMedium, size: 20))
            .padding(.horizontal)
            .frame(height: 50)
            .padding(EdgeInsets(top: 0, leading: 20, bottom: 0, trailing: 40))
            .submitLabel(.search)
            .overlay(
                Capsule()
                    .strokeBorder(style: StrokeStyle(lineWidth: 2, lineCap: .butt))
                    .foregroundColor(Color(hex: kGray))
            )
            .overlay(alignment: .trailing) {
                Button(action: search) {
                    Image(systemName: "magnifyingglass")
                        .resizable()
                        .frame(width: 40, height: 40)
                        .symbolVariant(.circle.fill)
                        .foregroundStyle(Color.black, Color(hex: kYellowButtonBackground))
                        .padding(.trailing, 5)
                }
            }
            .padding(.horizontal)
    }
    
    func search() {
        
    }
}

struct RecipesView_Previews: PreviewProvider {
    static var previews: some View {
        RecipesView(isLoggedIn: .constant(true))
    }
}
