//
//  RecipeFavouriteView.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 23/02/22.
//

import SwiftUI

struct RecipeExploreView: View {
    @Environment(\.presentationMode) var presentationMode
    @State var isLandScape = !Helper.shared.deviceIsOnPortraitMode()
    
    @Binding var isLoggedIn: Bool
    var foodType: String
    
    var body: some View {
        VStack(alignment: .leading) {
            RecipesTitleView(isLoggedIn: $isLoggedIn, forExplore: true) {
                presentationMode.wrappedValue.dismiss()
            }
            
            Text(foodType)
                .padding()
                .font(.custom(kPoppinsBold, size: 20))
            
            RecipeExploreCollection(coloumns: UIDevice.current.userInterfaceIdiom == .phone ? (isLandScape ? 3 : 2) : 3)
        }
        .navigationBarHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
        .onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in
            isLandScape = !Helper.shared.deviceIsOnPortraitMode()
        }
    }
}

struct RecipeExploreCollection: View {
    var coloumns: Int
   
    var body: some View {
        let layout = Helper.shared.getLayout(with: coloumns)
        
        ScrollView(showsIndicators: false) {
            Section {
                LazyVGrid(columns: layout, spacing: 20) {
                    ForEach(kTestRecipes, id: \.self) { recipe in
                        NavigationLink {
                            RecipeDetailView(recipe: recipe)
                        } label: {
                            RecipeExploreCell(recipe: recipe)
                        }
                    }
                }
                .padding(.horizontal)
            } footer: {
                FavouriteRecipeView()
            }
        }
    }
}

struct FavouriteRecipeView: View {
    var body: some View {
        VStack(alignment: .leading) {
            Text("Favourite")
                .font(.custom(kPoppinsBold, size: 20))
                .padding()
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    ForEach(kTestRecipes, id: \.self) { recipe in
                        VStack {
                            Image(recipe.image)
                                .resizable()
                                .frame(width: 60, height: 60)
                                .clipShape(Circle())
                            Text(recipe.name)
                                .font(.custom(kPoppinsBold, size: 12))
                                .lineLimit(1)
                        }
                        .frame(width: 120)
                    }
                }
            }
        }
    }
}

struct RecipeExploreView_Previews: PreviewProvider {
    
    static var previews: some View {
        RecipeExploreView(isLoggedIn: .constant(true), foodType: "Breakfast")
    }
    
}
