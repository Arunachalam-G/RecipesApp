//
//  LoginView.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 20/02/22.
//

import SwiftUI

enum Fields {
    case email, password
}

struct LoginView: View {
    
    @Binding var isLoggedIn: Bool
    @State var emailAddress: String = ""
    @State var password: String = ""
    @FocusState var activeField: Fields?
    @State var alertMessage: String = ""
    @State var showAlert = false
    
    var createAccountText: AttributedString {
        var text = AttributedString("Don't have account? Create new account.")
        text.font = .custom(kPoppinsBold, size: 15)
        text.foregroundColor = Color(hex: kCreateAccountTextColor)
        if let range = text.range(of: "Create new account.") {
            text[range].foregroundColor = Color(hex: kYellowButtonBackground)
        }
        return text
    }
    
    var body: some View {
        NavigationView {
            ScrollView(showsIndicators: false) {
                ZStack() {
                    Color(UIColor.white)
                    
                    VStack {
                        VStack(alignment: .leading) {
                            Image(kImageLogin)
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .overlay(TextOverlay())
                            
                            UserCredentialsInputView(input: $emailAddress, placeHolder: "Enter email address", sectionTitle: "EMAIL ADDRESS", isPassword: false, field: _activeField) {
                                activeField = .password
                            }
                            
                            Divider()
                                .padding(.horizontal, 30)
                                .padding(.bottom, 24)
                            
                            UserCredentialsInputView(input: $password, placeHolder: "Enter password", sectionTitle: "PASSWORD", isPassword: true, field: _activeField) {
                                activeField = .none
                            }
                            
                            Divider()
                                .padding(.horizontal, 30)
                        }
                        
                        VStack(alignment: .center, spacing: 24) {
                            Button(action: {}) {
                                Poppin(text: ("Forget Password?"), size: 15, font: kPoppinsBold, color: kYellowButtonBackground)
                            }
                            .padding(.top, 24)
                            
                            Button(action: login) {
                                Poppin(text: ("Login"), size: 22, font: kPoppinsBold, color: kBlack)
                                    .frame(width: 308, height: 63)
                                    .background(Color(hex: kYellowButtonBackground))
                                    .cornerRadius(18)
                            }
                            .disabled(loginDisabled())
                            .opacity(loginDisabled() ? 0.5 : 1)
                            .alert(alertMessage, isPresented: $showAlert) {
                                Button("Ok", role: .cancel) {
                                    alertMessage == kSingedIn ? isLoggedIn = true : nil
                                }
                            }
                            
                            NavigationLink(destination: SignupView(isLoggedIn: $isLoggedIn)) {
                                Text(createAccountText)
                            }
                        }
                        
                        Spacer()
                    }
                }
            }
            .ignoresSafeArea()
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    func loginDisabled() -> Bool {
        emailAddress.empty() || password.empty()
    }
    
    func login() {
        let existingUsers = Helper.shared.getUsers()
        if existingUsers.contains(where: { user in
            user.email == emailAddress && user.password == password
        }) {
            alertMessage = kSingedIn
        } else {
            alertMessage = kInvalidCredentials
        }
        showAlert = true
    }
    
}

struct UserCredentialsInputView: View {
    @Binding var input: String
    @State var placeHolder: String
    @State var sectionTitle: String
    var isPassword: Bool
    @FocusState var field: Fields?
    var onSubmit: () -> () = {}
    
    var body: some View {
        Poppin(text: sectionTitle, size: 12, font: kPoppinsBold, color: kGray)
            .padding(.horizontal, 30)
        
        if isPassword {
            SecureField(placeHolder, text: $input)
                .padding(.horizontal, 30)
                .foregroundColor(Color(hex: KTextFieldTextColor))
                .font(.custom(kPoppinsMedium, size: 15))
                .submitLabel(.done)
                .focused($field, equals: .password)
                .onSubmit { onSubmit() }
        } else {
            TextField(placeHolder, text: $input)
                .padding(.horizontal, 30)
                .foregroundColor(Color(hex: KTextFieldTextColor))
                .font(.custom(kPoppinsMedium, size: 15))
                .textInputAutocapitalization(.never)
                .submitLabel(.next)
                .focused($field, equals: .password)
                .onSubmit { onSubmit() }
        }
    }
}

struct Poppin: View {
    var text: String
    var size: CGFloat
    var font: String
    var color: String
    
    var body: some View {
        Text(text)
            .font(.custom(font, size: size))
            .foregroundColor(Color(hex: color))
    }
}

struct TextOverlay: View {
    
    var gradient: LinearGradient {
        LinearGradient(colors: [Color.white.opacity(0.4), Color.white.opacity(0)],
                       startPoint: .bottom,
                       endPoint: .top)
    }
    
    var body: some View {
        ZStack(alignment: .bottomLeading) {
            Rectangle().fill(gradient)
            VStack {
                Poppin(text: "Login", size: 30, font: kPoppinsBold, color: kBlack)
                    .padding()
            }
            .padding()
        }
    }
}

struct LoginView_Previews: PreviewProvider {
    static var previews: some View {
        LoginView(isLoggedIn: .constant(false))
    }
}
