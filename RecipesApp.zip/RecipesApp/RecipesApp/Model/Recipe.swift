//
//  Recipe.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 22/02/22.
//

import Foundation

struct Recipe: Codable, Hashable, Identifiable {
    var id = UUID().uuidString
    let name: String
    let type: String
    let rating: Double
    let image: String
    let duration: String
    let calories: Int
    let protein: Double
    let fat: Double
    let carbohydrates: Double
    let ingredients: [Ingredient]
}

struct Ingredient: Codable, Hashable {
    let name: String
    let quantity: String
    let image: String
}

let egg = Ingredient(name: "Egg", quantity: "1", image: "Egg")
let hamBun = Ingredient(name: "Ham-Bun", quantity: "2", image: "HamBun")
let lettuce = Ingredient(name: "Lettuce leaves", quantity: "4 iceberg", image: "Lettuce leaves")
let onion = Ingredient(name: "Onion", quantity: "4 thin slices", image: "Onion")

let cream = Ingredient(name: "Whipped cream", quantity: "3/4 cup", image: "Whipped-cream")
let choclate = Ingredient(name: "Bittersweet chocolate", quantity: "1 pound", image: "Bittersweet-chocolate")
let raspberry = Ingredient(name: "Raspberries", quantity: "1 pack", image: "Raspberries")

let sugar = Ingredient(name: "Sugar", quantity: "1/2 cup", image: "sugar")
let purposeFlour = Ingredient(name: "Purpose flour", quantity: "2 cup", image: "Purpose-flour")
let heavyCream = Ingredient(name: "Heavy cream", quantity: "1/3 cup", image: "Heavy cream")

let chicken = Ingredient(name: "Chicken Piece", quantity: "2", image: "Chicken")
let vegOil = Ingredient(name: "Vegetable oil ", quantity: "2 tablespoons", image: "vegOil")
let tacoSeasoning = Ingredient(name: "Taco seasoning", quantity: "1/4 cup", image: "TacoSeasoning")

let vennilaExtract = Ingredient(name: "Vennila extract", quantity: "1 1/2 teaspoons", image: "VennilaExtract")
let candy = Ingredient(name: "Sweet candies", quantity: "20 grams", image: "candy")
let milk = Ingredient(name: "Milk", quantity: "1/2 cup", image: "milk")
let nut = Ingredient(name: "Grated nutmeg", quantity: "3/4 teaspoon", image: "Grated nutmeg")

let kShreddedCoconut = Ingredient(name: "Shredded Coconut", quantity: "1/3 cup", image: "Shredded Coconut")
let kPeaches = Ingredient(name: "Peaches", quantity: "825 g", image: "Peaches")
let kOats = Ingredient(name: "Oats", quantity: "2 cups", image: "Oats")
let kSlicedMango = Ingredient(name: "Sliced Mango", quantity: "1 tin", image: "Sliced Mango")

let butter = Ingredient(name: "Butter", quantity: "1 cup", image: "Butter")

let kBurgerIngredients = [egg, hamBun, lettuce, onion]
let kRaspberryIngredients = [raspberry, choclate, cream]
let kCookieIngredients = [butter, sugar, purposeFlour, heavyCream]
let kChickenSaladIngredients = [chicken, butter, tacoSeasoning, vegOil]
let kDoughnutIngredient = [candy, milk, nut, vennilaExtract]
let kMangoPeachIngredient = [kPeaches, kSlicedMango, kShreddedCoconut, kOats]


let kTestRecipes = [
    Recipe(name: "Burger Mania", type: "Snacks", rating: 4.2, image: "R1", duration: "45 mins", calories: 250, protein: 75.1, fat: 10.2, carbohydrates: 20.3, ingredients: kBurgerIngredients),
    Recipe(name: "Raspberry Chocolate Truffles", type: "Snacks", rating: 4.8, image: "S3", duration: "30 mins", calories: 200, protein: 70.2, fat: 12.1, carbohydrates: 15.6, ingredients: kRaspberryIngredients),
    Recipe(name: "Chicken Taco Salad", type: "Breakfast", rating: 4.4, image: "S2", duration: "1 hour", calories: 280, protein: 65.1, fat: 30.2, carbohydrates: 40.3, ingredients: kChickenSaladIngredients),
    Recipe(name: "Cream Cookies", type: "Snacks", rating: 3.7, image: "R2", duration: "30 mins", calories: 150, protein: 50.2, fat: 15.1, carbohydrates: 13.6, ingredients: kCookieIngredients),
    Recipe(name: "Sweet Doughnuts", type: "Snacks", rating: 4.1, image: "R5", duration: "40 mins", calories: 210, protein: 55.4, fat: 14.1, carbohydrates: 17.1, ingredients: kDoughnutIngredient),
    Recipe(name: "Mango Peach Coconut Crumble", type: "Deserts", rating: 3.8, image: "S4", duration: "1 hour 15 mins", calories: 230, protein: 85.1, fat: 12.8, carbohydrates: 24.9, ingredients: kMangoPeachIngredient)
]


