//
//  User.swift
//  RecipesApp
//
//  Created by Arunachalam Ganesan on 26/02/22.
//

import Foundation

struct User: Codable {
    let name: String
    let email: String
    let password: String
}
